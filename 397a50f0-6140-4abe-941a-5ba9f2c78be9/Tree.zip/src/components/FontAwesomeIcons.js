import { library } from "@fortawesome/fontawesome-svg-core";

import { faCaretRight } from "@fortawesome/free-solid-svg-icons";

library.add( faCaretRight );